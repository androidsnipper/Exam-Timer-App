package com.example.exam_timer;

import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    MediaPlayer m1;
TextView mnumber,done;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        m1=MediaPlayer.create(this,R.raw.three);
        final TextView mnumber=findViewById(R.id.mnumber);
        final TextView done=findViewById(R.id.textView);

        new CountDownTimer(11000,1000){
            public void onTick(long millisecondsUntilDone){
                mnumber.setText(String.valueOf(millisecondsUntilDone/1000));
            }
            public void onFinish(){
                done.setText("Finished!!!");
                m1.start();
            }
        }.start();



    }
}
